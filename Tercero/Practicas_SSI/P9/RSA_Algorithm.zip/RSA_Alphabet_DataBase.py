""""
@file RSA_Alphabet_DataBase.py
@author Samuel Martín Morales (alu0101359526@ull.edu.es)
@brief This converts the characters into decimal numbers
@version 0.1
@date 2022-05-01

@copyright Copyright (c) 2022
"""

def Alphabet_DataBase(introduced_character):
    if (introduced_character == 'A'):
        return 0
    elif (introduced_character == 'B'):
        return 1
    elif (introduced_character == 'C'):
        return 2
    elif (introduced_character == 'D'):
        return 3
    elif (introduced_character == 'E'):
        return 4
    elif (introduced_character == 'F'):
        return 5
    elif (introduced_character == 'G'):
        return 6
    elif (introduced_character == 'H'):
        return 7
    elif (introduced_character == 'I'):
        return 8
    elif (introduced_character == 'J'):
        return 9
    elif (introduced_character == 'K'):
        return 10
    elif (introduced_character == 'L'):
        return 11
    elif (introduced_character == 'M'):
        return 12
    elif (introduced_character == 'N'):
        return 13
    elif (introduced_character == 'O'):
        return 14
    elif (introduced_character == 'P'):
        return 15
    elif (introduced_character == 'Q'):
        return 16
    elif (introduced_character == 'R'):
        return 17
    elif (introduced_character == 'S'):
        return 18
    elif (introduced_character == 'T'):
        return 19
    elif (introduced_character == 'U'):
        return 20
    elif (introduced_character == 'V'):
        return 21
    elif (introduced_character == 'W'):
        return 22
    elif (introduced_character == 'X'):
        return 23
    elif (introduced_character == 'Y'):
        return 24
    elif (introduced_character == 'Z'):
        return 25

    
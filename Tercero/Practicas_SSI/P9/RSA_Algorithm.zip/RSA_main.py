""""
@file RSA_main.py
@author Samuel Martín Morales (alu0101359526@ull.edu.es)
@brief Implementation of RSA algorithm
@version 0.1
@date 2022-05-01

@copyright Copyright (c) 2022
"""

from RSA_menu import Menu

if __name__ == '__main__':
    Menu()
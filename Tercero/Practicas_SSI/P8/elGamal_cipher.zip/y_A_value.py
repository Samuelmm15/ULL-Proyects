def y_A_B_value(a_value, k_x_value, p_value):
    y_a_b_value = (pow(int(a_value), int(k_x_value)) % int(p_value))
    return y_a_b_value
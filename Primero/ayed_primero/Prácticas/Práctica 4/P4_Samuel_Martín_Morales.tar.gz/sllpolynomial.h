// AUTOR: Samuel Martín Morales
// FECHA: 18/04/2021
// EMAIL: alu0101359526@ull.edu.es
// VERSION: 2.0
// ASIGNATURA: Algoritmos y Estructuras de Datos
// PRÁCTICA Nº: 4
// ESTILO: Google C++ Style Guide
// COMENTARIOS:
// 

#ifndef SLLPOLYNOMIAL_H_
#define SLLPOLYNOMIAL_H_

#include <iostream>
#include <math.h>  // fabs, pow

#include "pair_t.h"
#include "sll_t.h"
#include "vector_t.h"

#define EPS 1.0e-6

typedef pair_t<double> pair_double_t;  // Campo data_ de SllPolynomial
typedef sll_node_t<pair_double_t> SllPolyNode;  // Nodos de SllPolynomial

// Clase para polinomios basados en listas simples de pares
class SllPolynomial : public sll_t<pair_double_t> { /// clase heredada
 public:
  // constructores
  SllPolynomial(void) : sll_t() {};
  SllPolynomial(const vector_t<double>&, const double = EPS);

  // destructor
  ~SllPolynomial() {};

  // E/S
  void Write(std::ostream& = std::cout) const;
  
  // operaciones
  double Eval(const double) const; /// evaluación de un polinomio
  bool IsEqual(const SllPolynomial&, const double = EPS) const; /// comprobación de si son iguales
  void Sum(const SllPolynomial&, SllPolynomial&, const double = EPS); /// suma de dos polinomios
  void Pairpolynomial(SllPolynomial& sllpar) const;
};


bool IsNotZero(const double val, const double eps = EPS) { /// comprobacion de si alguna celda del vector es igual a cero.
  return fabs(val) > eps;
};

// FASE II
// constructor
SllPolynomial::SllPolynomial(const vector_t<double>& v, const double eps) { /// constructor del polinomio
  pair_double_t variable;
  SllPolyNode *aux;
  
  int counter = 0;
  for (int i = 0; i < v.get_size(); i++) {
    if (IsNotZero(v.get_val(i), eps) == true) {
      counter++;
      variable.set(v.get_val(i), i);
      aux = new SllPolyNode [1];
      aux->set_data(variable);
      push_front(aux); 
    }
  }
};


// E/S
void SllPolynomial::Write(std::ostream& os) const {
  os << "[ ";
  bool first{true};
  SllPolyNode* aux{get_head()};
  while (aux != NULL) {
    int inx{aux->get_data().get_inx()};
    double val{aux->get_data().get_val()};
    if (val > 0)
      os << (!first ? " + " : "") << val;
    else
      os << (!first ? " - " : "-") << fabs(val);
    os << (inx > 1 ? " x^" : (inx == 1) ? " x" : "");
    if (inx > 1)
      os << inx;
    first = false;
    aux = aux->get_next();
  }
  os << " ]" << std::endl;
};

std::ostream& operator<<(std::ostream& os, const SllPolynomial& p) {
  p.Write(os);
  return os;
};


// Operaciones con polinomios

// FASE III
// Evaluación de un polinomio representado por lista simple
double SllPolynomial::Eval(const double x) const {
  double result{0.0};
  double unknown = x;
  SllPolyNode *aux{get_head()};
  bool first{true};

  while (aux != NULL) {
    int inx{aux->get_data().get_inx()};
    double val{aux->get_data().get_val()};
    if (inx == 0) {
      result = result + val;
    } else if (inx == 1) {
      result = result + (val * x);
    } else if (inx > 1) {
      for (int i = 2; i <= inx; i++) {
        unknown = (unknown * x);
      }
      result = result + (val * unknown);
      unknown = x;  
    }
    aux = aux->get_next();
  }
  return result; 
};

// Comparación si son iguales dos polinomios representados por listas simples
bool SllPolynomial::IsEqual(const SllPolynomial& sllpol, const double eps) const {
  bool differents = false;
  SllPolyNode *aux{get_head()};
  SllPolyNode *aux_sllpol{sllpol.get_head()};
  int counter = 0;
  int counter_aux = 0;

  while (aux != NULL) {      
    aux = aux->get_next();
    counter++;
  }

  while(aux_sllpol != NULL) {
    aux_sllpol = aux_sllpol->get_next();
    counter_aux++;
  }
  
  if (counter == counter_aux) {
    aux = get_head();
    aux_sllpol = sllpol.get_head();

    while ((aux != NULL) && (aux_sllpol != NULL)) {
      double val{aux->get_data().get_val()};
      double val_sllpol{aux_sllpol->get_data().get_val()};

      if ((IsNotZero(val, eps) == true) && (IsNotZero(val_sllpol,eps) == true)) {
        if ((val != val_sllpol)) {
          differents = true;
        } 
      }    
      
      aux = aux->get_next();
      aux_sllpol = aux_sllpol->get_next();
    }
  } else {
    differents = true;
  }

  return !differents; 
};

// FASE IV
// Generar nuevo polinomio suma del polinomio invocante mas otro polinomio
void SllPolynomial::Sum(const SllPolynomial& sllpol, SllPolynomial& sllpolsum, const double eps) {
  SllPolyNode *aux{get_head()};
  SllPolyNode *aux_sllpol{sllpol.get_head()};
  
  pair_double_t variable;
  SllPolyNode *aux_sllpolsum;
  
  while ((aux != NULL) && (aux_sllpol != NULL)) {
    int inx{aux->get_data().get_inx()};
    double val{aux->get_data().get_val()};

    int inx_sllpol{aux_sllpol->get_data().get_inx()};
    double val_sllpol{aux_sllpol->get_data().get_val()};

    double result = 0;

    if ((inx == 0) && (inx_sllpol == 0)) {
      
      result = val + val_sllpol;
      variable.set(result, inx);
      aux_sllpolsum = new SllPolyNode [1];
      aux_sllpolsum->set_data(variable);
      sllpolsum.push_front(aux_sllpolsum);

    } else if ((inx >= 1) && (inx_sllpol >= 1)) {
      if (inx == inx_sllpol) {

        result = val + val_sllpol;
        variable.set(result, inx);
        aux_sllpolsum = new SllPolyNode [1];
        aux_sllpolsum->set_data(variable);
        sllpolsum.push_front(aux_sllpolsum);

      }
    }
    
    if ((inx == inx_sllpol) || (inx > inx_sllpol) || (inx < inx_sllpol)) {
      aux = aux->get_next();
    }
    if ((inx_sllpol == inx) || (inx_sllpol > inx) || (inx_sllpol < inx)) {
      aux_sllpol = aux_sllpol->get_next();
    }
  } 

};

// Modificación
void SllPolynomial::Pairpolynomial(SllPolynomial& sllpar) const {
  SllPolyNode *aux{get_head()};
  
  SllPolyNode *aux_pair;
  pair_double_t variable;

  int counter = 0;

  while (aux != NULL) {
    int inx{aux->get_data().get_inx()};
    double val{aux->get_data().get_val()};
    if (inx % 2 == 0) {
      variable.set(val, inx);
      aux_pair = new SllPolyNode [1];
      aux_pair->set_data(variable);
      sllpar.push_front(aux_pair);
    }
    aux = aux->get_next();
  }
}; 


#endif  // SLLPOLYNOMIAL_H_

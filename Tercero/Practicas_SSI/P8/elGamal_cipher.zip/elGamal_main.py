""""
 @file elGamal_main.py
 @author Samuel Martín Morales (alu0101359526@ull.edu.es)
 @brief Implementation of elGamal algorithm
 @version 0.1
 @date 2022-04-23
  
 @copyright Copyright (c) 2022
"""

from elGamal_menu import Menu

if __name__ == '__main__':
    Menu()

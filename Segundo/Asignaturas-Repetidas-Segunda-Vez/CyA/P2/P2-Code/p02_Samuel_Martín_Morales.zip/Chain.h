/**
 * @file Chain.h
 * @author Samuel Martín Morales (alu0101359526@ull.edu.es)
 * @brief This file implemets the Chain class.
 * @version 0.1
 * @date 2022-10-05
 * @signature Computabilidad y Algoritmia.
 * @course 2022-2023.
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include <iostream>
#include "Alphabet.h"

#pragma once

/**
 * @brief This is the class that represents the chain formed by the alphabets.
 * 
 */
class Chain : public Alphabet {
  public:
    Chain();
    ~Chain();
    void AddChain(std::string newChain, Alphabet alphabet);
    std::string InverseChain();
    std::string ConcatenateChain(std::string firstCHain, std::string secondChain);
    std::string getChain();
  private:
    std::string chain;
    Alphabet alphabetChain;
};
